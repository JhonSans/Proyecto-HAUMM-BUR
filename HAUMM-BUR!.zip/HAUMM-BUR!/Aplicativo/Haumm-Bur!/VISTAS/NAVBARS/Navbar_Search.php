<?php
echo '<form action="../CONTROLADOR/Controlador_Consulta.php" method="post">
		<div class="box">
			<div class="container-2">
				<span class="icon"><i class="fa fa-search"></i></span>
				<input type="search" name="num_id" id="search" placeholder="N° Documento/NIT" />
			</div>
		</div>
	</form>';
?>