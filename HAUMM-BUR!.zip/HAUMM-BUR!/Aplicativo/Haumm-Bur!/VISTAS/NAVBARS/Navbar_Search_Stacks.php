<?php
echo '<form ><div class="box">
		<div class="container-2">
			<span class="icon"><i class="fa fa-search"></i></span>
			<input type="search" id="search" placeholder="N° Referencia"/>
		</div>
	</div></form>';
?>